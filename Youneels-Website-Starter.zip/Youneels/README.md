# Youneels — Phase 1 website starter

This is a responsive front-end starter for the Youneels global social video platform.

## Run it
Open `index.html` in a modern browser, or publish this folder using GitHub Pages.

## Included in this first build
- Responsive desktop, tablet, and mobile layout
- Original Youneels visual identity
- Social feed with sample posts
- Create a text post and preview selected image/video locally
- Like/follow interactions (front-end preview)
- Search posts in the visible feed
- Navigation placeholders for Explore, Videos, Shorts, Notifications, Messages, Bookmarks, Profile, and Creator Studio

## Important
This is the first front-end build, not a production social network yet. Accounts, secure login, persistent posts, cloud video storage/streaming, real-time chat/calls, notifications, moderation, and global scaling require a backend, database, storage, and security rules. Those cannot honestly be represented as finished by a static free website. Build those as the next phases using free tiers where available, with usage limits and possible future costs.
